

<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="p-4 sm:ml-64">

    <header class="mt-10">
        <div class="w-full text-center">
            <h1 class="text-xl font-medium leading-relaxed uppercase border-b-2 border-gray-300">Display Dashboard</h1>
        </div>
    </header>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODE\Laravel\fids_laravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>