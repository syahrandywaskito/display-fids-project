

<?php $__env->startSection('title'); ?>
    Departure Schedule
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <header class="bg-[#1c8f36] font-semibold text-white">
    <img src="<?php echo e(asset('img/logo.png')); ?>" class=" w-96  absolute -top-28 -left-44 opacity-60" alt="">

    <div class="flex py-8 pl-24 pr-14 items-center font-medium">
        <h1 class="mr-auto text-5xl z-20">Departure Flight</h1>
        <h3 class="mr-10 text-xl z-20"><?php echo e($date); ?></h3>
        <h2 class="text-5xl z-20 clock"></h2>
    </div>

    <img src="<?php echo e(asset('img/logo.png')); ?>" class=" w-72  absolute top-10 right-0 opacity-60" alt="">
</header>

<section class="relative overflow-x-auto">
    <table class="w-full text-left rtl:text-right text-black font-medium">
        <thead class=" text-gray-100 capitalize text-xl bg-[#0a4580]">
            <tr>
                <th scope="col" class="pl-24">
                    Airline
                </th>
                <th scope="col" class="py-4">
                    Flight
                </th>
                <th scope="col" class="py-4">
                    Destination
                </th>
                <th scope="col" class="py-4 pr-44">
                    Time
                </th>
            </tr>
        </thead>
        

        <tbody class="text-xl font-semibold uppercase">
            <?php $__currentLoopData = $departures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr class="bg-white border-b

                     
                    "> 
                    <th scope="row" class="pl-20 font-medium text-gray-900 whitespace-nowrap">
                        <img src="
                            <?php if($data->nama_maskapai == 'Citilink'): ?> 
                                <?php echo e(asset('img/QG.png')); ?>

                            <?php elseif($data->nama_maskapai == 'Garuda Indonesia'): ?>
                                <?php echo e(asset('img/GA.png')); ?>

                            <?php else: ?> 
                                <?php echo e(asset('img/ID.png')); ?>

                            <?php endif; ?>
                            " class="w-[12rem]">
                    </th>
                    <td class="tracking-wide">
                        <?php echo e($data->id_penerbangan); ?>

                    </td>
                    <td class="text-blue-800 tracking-wider">
                        <?php echo e($data->tujuan); ?>

                    </td>
                    <td class="text-blue-800 tracking-wide">
                        <?php
                        $formattedTime = date('H:i', strtotime($data->waktu));
                        echo $formattedTime;
                        ?>
                    </td>
                </tr>   

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</section>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    $(document).ready(function() {
        // Function to update the clock display
        function updateClock() {
            const now = new Date();
            const hours = now.getHours();
            const minutes = now.getMinutes();
            const seconds = now.getSeconds();

            const formattedTime = `${formatNumber(hours)}:${formatNumber(minutes)}`;

            $(".clock").html(formattedTime);
        }

        // Helper function to format numbers with leading zeros
        function formatNumber(number) {
            return (number < 10 ? "0" : "") + number;
        }

        // Update the clock every second
        setInterval(updateClock, 1000);

        // Initial clock update
        updateClock();
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODE\Laravel\fids_laravel\resources\views/departure/index.blade.php ENDPATH**/ ?>