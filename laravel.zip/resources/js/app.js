import './bootstrap';
import "flowbite";